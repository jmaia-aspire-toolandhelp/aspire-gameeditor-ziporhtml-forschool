// Available: gameObject, threeObject, deltaTime
// Example: this.counter = (this.counter || 0) + 1;
// Example: gameObject.getComponent('AudioSource').play();

function onUpdate(deltaTime, gameObject, threeObject) {
    // threeObject.rotation.y += 1 * deltaTime;
}
